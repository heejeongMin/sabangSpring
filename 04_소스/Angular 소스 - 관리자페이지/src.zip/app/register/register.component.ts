import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormArray, FormGroup, FormControl} from '@angular/forms';

import { SwiperConfigInterface  } from 'ngx-swiper-wrapper';

import { MyhouseService } from '../menu/myhouse.service';
import { RegisterForm } from './register-form';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: [
    './register.component.css',
  ],
  providers:[MyhouseService]
})
export class RegisterComponent implements OnInit {
  btnFlg:boolean = false;    
  isDisabled:boolean = false; 
  zip:string = "";
  addr:string = "";
  desLength:number = 0;
  optDesLength:number = 0;
  newCode:string = "";
  optionArr:string[] = [];

  constructor(private service:MyhouseService, private fb: FormBuilder) { }
  ngOnInit() { }

  //swiper---------
  config:SwiperConfigInterface = {
    navigation : {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  };//end config
  slideChange(lastPage){
    this.btnFlg = (lastPage.className == "swiper-slide swiper-slide-active")? true:false;
  }//end slideChange

  //daum address api ------------
  daumAddressOptions =  {
    class: ['btn', 'btn-primary']
  }//end daumAddressOptions
  setDaumAddressApi(data){
    this.zip = data.zip;
    this.addr = data.addr;
  }//end setDaumAddressApi

  //textarea 글자수 세기 ------------
  description(e){
    if (e.target.name == "hetc"){
      this.desLength = e.target.textLength;
    }else{
      this.optDesLength = e.target.textLength;
    }
  }//end description

  // 등록하려는 htype의 마지막 코드를 가지고 와서 +1 -----------------
  getLastHcode(htype){
    this.service.getLastCode(htype).subscribe(res=>{ 
      var newNum = Number.parseInt(res["lastCode"])+1;      
      switch(htype){
          case "o": this.newCode = (newNum<10)? "O00" + newNum : ((newNum < 100)? "O0" + newNum :"O"+ newNum); break;
          case "t": this.newCode = (newNum<10)? "T00" + newNum : ((newNum < 100)? "T0" + newNum :"T"+ newNum); break;
					case "f": this.newCode = (newNum < 10)? "F00" + newNum : ((newNum < 100)? "F0" + newNum : "F"+ newNum); break;
					case "p": this.newCode = (newNum < 10)? "P00" + newNum : ((newNum < 100)? "P0" + newNum : "P"+ newNum); break;
					}//end switch
      });//end service
  }//end getLastHcode()

  // 파일업로드 -----------------
  //https://github.com/kzrfaisal/angular-file-uploader/blob/master/src/app/app.component.ts
  afuConfig ={
    multiple: false,
    formatsAllowed: ".jpg",
    theme: "dragNDrop",
    uploadAPI:  {
      url:"http://localhost:8090/sabang/angular/fileupload",
      // headers: { //이거 넣으면 500에러, CORS 에러남. 왜??? 
      //   "Content-Type": "multipart/form-data"
      // }
    },
    hideProgressBar: false,
    hideResetBtn: true,
    hideSelectBtn: true,
    replaceTexts: {
      selectFileBtn: 'Select Files',
      resetBtn: 'Reset',
      uploadBtn: 'Upload',
      dragNDropBox: 'Drag N Drop',
      attachPinBtn: 'Attach Files...',
      afterUploadMsg_success: 'Successfully Uploaded !',
      afterUploadMsg_error: 'Upload Failed !'
    }
  }

  DocUpload(env) {
    console.log(env);

  }
  
 // 폼데이터 가져오기 -----------------
  profileForm = this.fb.group({
    htype: [{value: '', disabled: this.isDisabled}],
    rtype: [{value: '', disabled: this.isDisabled}],
    hname: [{value: '', disabled: this.isDisabled}],
    hetc: [{value: '', disabled: this.isDisabled}],
    area: [{value: '', disabled: this.isDisabled}],
    flr: [{value: '', disabled: this.isDisabled}],
    whflr: [{value: '', disabled: this.isDisabled}],
    room: [{value: '', disabled: this.isDisabled}],
    batr: [{value: '', disabled: this.isDisabled}],
    post :[{value: '', disabled: this.isDisabled}],
    address : [{value: '', disabled: this.isDisabled}],
    deposit: [{value: '', disabled: this.isDisabled}],
    mrent: [{value: '', disabled: this.isDisabled}],
    yrent: [{value: '', disabled: this.isDisabled}],
    maintc: [{value: '', disabled: this.isDisabled}],
    parkf: [{value: '', disabled: this.isDisabled}],
    option: [{value: '', disabled: this.isDisabled}],
    etc:[{value: '', disabled: this.isDisabled}],
    
  });

  //폼데이터중 checkbox로 되어 있는애 가져오기
  options(e){
    if (e.target.checked==true){
      this.optionArr.push(e.target.value);
    } else {
      var newArr:string[] = [];
      for(var i of this.optionArr){
        if(i!=e.target.value) newArr.push(i);
      }
      this.optionArr = newArr;
    }
  }
  onSubmit(){
    var registerData = new RegisterForm(
      this.newCode,
      this.newCode.slice(0,1).toLowerCase(),
      this.profileForm.value.rtype,
      this.profileForm.value.hname,
      this.profileForm.value.hetc,
      this.profileForm.value.area,
      this.profileForm.value.flr,
      this.profileForm.value.whflr,
      this.profileForm.value.room,
      this.profileForm.value.batr,
      this.zip,
      this.addr,
      this.profileForm.value.deposit,
      this.profileForm.value.mrent,
      this.profileForm.value.yrent,
      this.profileForm.value.maintc,
      this.profileForm.value.parkf,
      this.optionArr,
      this.profileForm.value.etc);//end registerData

    console.log(registerData);
    this.service.houseRegister(registerData, "POST").subscribe(res => {
      var mesg = (res==1)? "매물등록에 성공하였습니다. Happy Sabang~":"매물등록에 실패하였습니다. 관리자에게 문의해주세요.";
      alert(mesg);
      this.isDisabled = !(this.isDisabled);
      this.profileForm.disable();
    });
    
  
  }

  unDisable(){
    this.isDisabled = !(this.isDisabled);
    this.profileForm.enable();
  }

 
 

 

  



 

  


}

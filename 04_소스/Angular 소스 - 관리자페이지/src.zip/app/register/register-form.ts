export class RegisterForm {
    

    constructor(public hcode:string,
                public htype:string,
                public rtype:string,
                public hname:string,
                public hetc:string,
                public area:string,
                public flr:number,
                public whflr:number,
                public room:number,
                public batr:string,
                public post:string,
                public addr:string,
                public deposit:number,
                public mrent:number,
                public yrent:number,
                public maintc:number,
                public parkf:number,
                public options:string[],
                public etc:string ){

    }

}

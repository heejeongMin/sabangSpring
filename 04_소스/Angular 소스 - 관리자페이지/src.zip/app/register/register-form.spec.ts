import { RegisterForm } from './register-form';

describe('RegisterForm', () => {
  it('should create an instance', () => {
    expect(new RegisterForm()).toBeTruthy();
  });
});

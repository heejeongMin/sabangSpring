import { AgentHouseBoard } from './agent-house-board';

describe('AgentHouseBoard', () => {
  it('should create an instance', () => {
    expect(new AgentHouseBoard()).toBeTruthy();
  });
});

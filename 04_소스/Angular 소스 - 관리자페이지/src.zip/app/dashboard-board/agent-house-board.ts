export class AgentHouseBoard {
    constructor(public hcode:string,
                public userid:string,
                public postdate:string,
                public title:string,
                public content:string
        ){};
}

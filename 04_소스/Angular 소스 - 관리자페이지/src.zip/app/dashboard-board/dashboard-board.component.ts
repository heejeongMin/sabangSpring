import { Component, OnInit } from '@angular/core';
import { MyhouseService } from '../menu/myhouse.service'
import { AgentHouseBoard } from './agent-house-board';
import {trigger, transition, style, animate, query, stagger, keyframes} from '@angular/animations';

@Component({
  selector: 'app-dashboard-board',
  templateUrl: './dashboard-board.component.html',
  styleUrls: ['./dashboard-board.component.css'],
  providers: [MyhouseService],
  animations: [  // https://www.youtube.com/watch?v=h-bUT5BMQrI
    trigger('listAnimation', [
      transition('* => *', [
        query(':enter', style({opacity:0}), {optional:true}),

        query(':enter', stagger('100ms', [
          animate('1s ease-in', keyframes([
            style({opacity:0, transform:'translateY(-200px)', offset:0}),
            style({opacity:.3, transform:'translateY(-100px)', offset:.3}),
            style({opacity:.6, transform:'translateY(-50px)', offset:.6}),
            style({opacity:1, transform:'translateY(0px)', offset:1}),
          ]))
        ]), {optional:true}),
      ])
    ])
  ]
})
export class DashboardBoardComponent implements OnInit {
  boardData:AgentHouseBoard[] = [];
  constructor(private service:MyhouseService) { }

  ngOnInit() {
    this.boardData = [];
    this.service.agentHouseBoard().subscribe(data=>{
      this.boardData = data as AgentHouseBoard[];   
    });
  }

  flag:boolean = false; 
  commentFlag:boolean = false;
  makeCommentArea:boolean = false; 
  postBtnActive:boolean = false;
  hcode:string;
  openReply(e, i){
    this.hcode=i;
    this.flag= !this.flag;  
    this.commentFlag = false; 
    this.makeCommentArea = false;
    this.postBtnActive = false;
  }

  showReply(e){
    e.stopPropagation();
    this.commentFlag = !this.commentFlag;
    this.makeCommentArea = false;
    this.postBtnActive = false;
  }
  makeComment(e){
    e.stopPropagation();
    this.commentFlag = true;
    this.makeCommentArea = !this.makeCommentArea;
    this.postBtnActive = false;
  }
  textAreaClick(e){
    e.stopPropagation();
  }
  commentPost(e){
    this.postBtnActive = (e.target.textLength > 0)? true:false;
  }
  submitComment(e, comment:string){
    e.stopPropagation();
  }

}

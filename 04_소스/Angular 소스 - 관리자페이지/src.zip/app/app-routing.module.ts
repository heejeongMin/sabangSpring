import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardChartComponent } from './dashboard-chart/dashboard-chart.component';
import { MenuComponent } from './menu/menu.component'
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {path:'', component:DashboardChartComponent},
  {path:'dashboard', component:DashboardChartComponent},
  {path:'myhouse', component:MenuComponent},
  {path:'register', component:RegisterComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

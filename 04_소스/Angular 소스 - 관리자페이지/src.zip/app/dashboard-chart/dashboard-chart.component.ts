import { Component, OnInit } from '@angular/core';

import { MyhouseService } from '../menu/myhouse.service';
import { RecordData } from './record-data';
import { RecordSoldData } from './record-sold-data'
import { LikeData } from './like-data';

@Component({
  selector: 'app-dashboard-chart',
  templateUrl: './dashboard-chart.component.html',
  styleUrls: ['./dashboard-chart.component.css'],
  providers: [MyhouseService],
})

export class DashboardChartComponent implements OnInit {
  constructor(private service:MyhouseService) {}
  chartType = ['LineChart', 'PieChart'];
  openItems = new Array();
  rows = new Array ();

  lineChartDataAll:RecordData[] = [];
  lineChartDataSold:RecordSoldData[] = [];
  pieChartDataLike:LikeData[] = [];
  
  lineChartColumns = ['month', '진행', '완료'];
  pieChartColumns = ['HCODE', 'CNTWISH'];

  lineOptions = {
    hAxis: {
      title: '월',
      ticks: [1,2,3,4,5,6,7,8,9,10,11,12]
    },
    vAxis: {
      title: '매물수',
      scaleType: 'none'
    },
    colors: ['#AB0D06', '#007329'],
    width:500,
    height:200,
  }
  pieOptions = {
      'title':'매물 인기도(중개중인 매물 기준)',
      'width': 400,
      'height':250,
  }


  ngOnInit() {    
    //line chart 데이터
    this.service.recordChart().subscribe(recordData=>{ 
      this.lineChartDataAll = recordData as RecordData[]; 
      this.service.recordChartSold().subscribe(recordSoldData=>{ 
        this.lineChartDataSold = recordSoldData as RecordSoldData[];
        this.readyLineChartData();
      });  
   });//end line chart

   //pie chart 데이터
   this.service.likeChartHouse().subscribe(likeData=>{
      this.pieChartDataLike = likeData as LikeData[];
      this.readyPieChartData();
   });

  }//end ngOnInit

  //pie chart data
  readyPieChartData(){
    this.rows = new Array();
    for(let i=0; i<this.pieChartDataLike.length; i++){
      this.rows[i] = [this.pieChartDataLike[i]["HCODE"], this.pieChartDataLike[i]["CNTWISH"]]; 
    }
  }

  //line chart data
  readyLineChartData(){ 
    this.openItems = new Array();
    for(let i=1; i<13; i++){//1~12월
      let month = (i < 10)? "0"+i:i;
      this.openItems[i-1] = [i];
      for (let j=0; j<this.lineChartDataAll.length; j++ ){
        if (month == this.lineChartDataAll[j]["REGISTERDATE"]){
          this.openItems[i-1].push(this.lineChartDataAll[j]["COUNT"]);
        }
      }
        for (let j=0; j<this.lineChartDataSold.length; j++ ){
          if (month == this.lineChartDataSold[j]["CLOSEDDATE"]){   
            if (this.openItems[i-1].length == 2){
              this.openItems[i-1].push(this.lineChartDataSold[j]["COUNT"]);
            }else{
              this.openItems[i-1].push(0);
              this.openItems[i-1].push(this.lineChartDataSold[j]["COUNT"]);
            }    
          }  
      }//end 중첩 for 
  }//end for

  for(let i in this.openItems){
    if(this.openItems[i].length == 1){
      this.openItems[i].push(0, 0);
    } else if (this.openItems[i].length < 3){
      this.openItems[i].push(0);
    }
  }//end for
}
}

import { RecordData } from './record-data';

describe('RecordData', () => {
  it('should create an instance', () => {
    expect(new RecordData()).toBeTruthy();
  });
});

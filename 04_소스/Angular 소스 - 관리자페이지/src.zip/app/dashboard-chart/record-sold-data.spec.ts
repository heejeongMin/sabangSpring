import { RecordSoldData } from './record-sold-data';

describe('RecordSoldData', () => {
  it('should create an instance', () => {
    expect(new RecordSoldData()).toBeTruthy();
  });
});

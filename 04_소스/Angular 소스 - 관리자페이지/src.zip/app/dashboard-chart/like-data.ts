export class LikeData {
    constructor(public hcode:string, public cntwish:number){}
}

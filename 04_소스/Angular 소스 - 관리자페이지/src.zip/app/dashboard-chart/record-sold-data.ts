export class RecordSoldData {
    constructor(public count:number, public closeddate:string){}
}

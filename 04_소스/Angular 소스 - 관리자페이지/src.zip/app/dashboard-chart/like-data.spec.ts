import { LikeData } from './like-data';

describe('LikeData', () => {
  it('should create an instance', () => {
    expect(new LikeData()).toBeTruthy();
  });
});

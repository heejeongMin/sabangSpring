export class RecordData {
    constructor(public count:number, public registerdate:string){}
}

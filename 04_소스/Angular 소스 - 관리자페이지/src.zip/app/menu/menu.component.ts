import { Component, OnInit, Input } from '@angular/core';
import { MyhouseService } from './myhouse.service';
import { House } from './house';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css'],
  providers: [MyhouseService],
})
export class MenuComponent implements OnInit {
  agentHouse:House[];
  agentSoldHouse:House[];
  
  constructor(private myHouseService:MyhouseService){}

  ngOnInit() {
    this.myHouseService.getHouse().subscribe(house => this.agentHouse = house);
    this.myHouseService.getSoldHouse().subscribe(house => this.agentSoldHouse = house);
  }

 
 

}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';

import { Observable, pipe } from 'rxjs';
import { map } from 'rxjs/operators';

import { House } from './house';
import { RegisterForm } from '../register/register-form';


@Injectable({
  providedIn: 'root'
})
export class MyhouseService {

  constructor(private http:HttpClient){}

  //중개중인 매물가져오기
  getHouse():Observable<House[]>{
    var url = "http://localhost:8090/sabang/angular/houseList";  
    return this.http.get(url).pipe(map(house => house as House[]));
  }

  //중개완료매물가져오기
  getSoldHouse():Observable<House[]>{
    var url="http://localhost:8090/sabang/angular/houseSoldList";
    return this.http.get(url).pipe(map(house => house as House[]));
  }

  //중개인에의해 변동된 중개중/중개완료 매물 저장하기 
  saveHouseChange(houseData:string[][]){
    var url = "http://localhost:8090/sabang/angular/saveHouseChange";
    return this.http.put(url, houseData);
  }

  //실적 chart 그리기위한 등록매물정보 가지고 오기
  recordChart(){
    var url = "http://localhost:8090/sabang/angular/recordChart";
    return this.http.get(url).pipe(map(data=>data));
  }
  //실적 chart 그리기위한 sold매물 정보
  recordChartSold(){
    var url = "http://localhost:8090/sabang/angular/recordChartSold";
    return this.http.get(url).pipe(map(data=>data));
  }

  //인기매물 chart 그리기위한 정보 가지고 오기
  likeChartHouse(){
    var url = "http://localhost:8090/sabang/angular/likeChartHouse";
    return this.http.get(url).pipe(map(data=>data));
  }

  //에이전트별로 올린 매물에 대한 모든 board 리스트 가져오기 (dashboard 용)
  agentHouseBoard(){
    var url = "http://localhost:8090/sabang/angular/agentHouseBoard";
    return this.http.get(url).pipe(map(data=>data));
  }

  //매물 삭제 서비스
  deleteHouse(hcode:string){
    var url= `http://localhost:8090/sabang/angular/DELETE/${hcode}`;
    return this.http.delete(url).pipe(map(data=>data));
  }

  //마지막 매물 코드 가져오기
  getLastCode(htype:string){
    var url = `http://localhost:8090/sabang/angular/houseManaging/GET/${htype}`;
    return this.http.get(url).pipe(map(data => data));
  }

  //매물등록 (w/o 파일)
  houseRegister(house:RegisterForm, workType:string){
    var url = `http://localhost:8090/sabang/angular/houseRegister/${workType}`;
    return this.http.post(url, house).pipe(map(data=>data));
  }

}

import { House } from './house';

describe('House', () => {
  it('should create an instance', () => {
    expect(new House()).toBeTruthy();
  });
});

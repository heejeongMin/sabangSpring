import { TestBed } from '@angular/core/testing';

import { MyhouseService } from './myhouse.service';

describe('MyhouseService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MyhouseService = TestBed.get(MyhouseService);
    expect(service).toBeTruthy();
  });
});

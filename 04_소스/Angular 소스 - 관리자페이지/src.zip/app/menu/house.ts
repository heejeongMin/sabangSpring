export class House {

    constructor(public HCODE:string, 
                public MRENT:number,
                public HIMAGE:string, 
                public RTYPE:string,
                public REGISTERDATE:number,
                public ADDR:string,
                public DEPOSITE:number ){}
}
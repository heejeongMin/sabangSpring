import { Directive, ElementRef, HostListener, ɵConsole } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem, DropListRef } from '@angular/cdk/drag-drop';
import { OnSaleComponent } from './on-sale.component';

@Directive({
  selector: '[appMovedHouse]'
})
export class MovedHouseDirective {
  sc:OnSaleComponent;
  constructor(public e:ElementRef) {
   
  }



}

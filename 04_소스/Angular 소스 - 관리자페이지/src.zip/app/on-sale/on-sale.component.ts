import { Component, Input } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';

import { House } from '../menu/house';
import { MyhouseService } from '../menu/myhouse.service';
// import { container } from '@angular/core/src/render3';
// import { flatMap } from 'rxjs/operators';

@Component({
  selector: 'app-on-sale',
  templateUrl: './on-sale.component.html',
  styleUrls: ['./on-sale.component.css'],
  providers: [MyhouseService]
})
export class OnSaleComponent {
  //처음 DB에서 가지고온 매물정보
  @Input() agentHouse:House[];
  @Input() agentSoldHouse:House[];

  state:boolean = false; 


  constructor(private houseService:MyhouseService){};

  drop(event: CdkDragDrop<string[]>, hcode) {   
    this.state = true;
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex); 
    } else {    
      transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex,event.currentIndex);        
      }
  }//end drop

  revert(){
    alert("저장하지 않은 변동사항은 모두 취소됩니다.");
    location.href="myhouse";
  }


  saveHouseChange(){
    var onSaleToSave:string[] = [];
    var soldToSave:string[] = [];
    
    //중개중인 매물 리스트에 담기
    for (let i=0; i<this.agentHouse.length; i++){
      onSaleToSave.push(this.agentHouse[i].HCODE);
    }
    //중개완료 매물 리스트에 담기
    for (let i=0; i<this.agentSoldHouse.length; i++){       
      soldToSave.push(this.agentSoldHouse[i].HCODE);
    }
    
    this.houseService.saveHouseChange([onSaleToSave, soldToSave])
                     .subscribe(res=>{
                      if (res>0){
                         alert("변경사항을 성공적으로 저장하였습니다");
                       }else{
                         alert("변경사항 저장에 실패하였습니다. 관리자에게 문의하여 주시기 바랍니다.");
                       }                 
                     });
  }

  rightClickMsgFlag:boolean = false;
  hcode:string;
  rightClickMsgPosition:{};
  rightClick(e, hcode){
    e.preventDefault();
    this.hcode=hcode;
    this.rightClickMsgFlag = !this.rightClickMsgFlag;
    this.rightClickMsgPosition = {left:e.clientX+"px", top:e.clientY+"px"};
  }
  leftClick(e){
    this.rightClickMsgFlag = !this.rightClickMsgFlag;
  }

  delete(e, delTarget){
   e.stopPropagation();
   var confirmYN = confirm("해당 매물을 삭제하시겠습니까?");
   if(confirmYN!=undefined) {
     this.rightClickMsgFlag = false;
     if(confirmYN == true){
       this.houseService.deleteHouse(this.hcode).subscribe(data=>{
         if(data == "0") {
           alert("매물 삭제에 실패하였습니다. 관리자에게 문의하여주시기 바랍니다.");
         } else {
           alert("성공적으로 삭제하였습니다.");
           delTarget.remove();         
         }
       });
       
    }
    } 
  }


}

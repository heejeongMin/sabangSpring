import { MovedHouseDirective } from './moved-house.directive';

describe('MovedHouseDirective', () => {
  it('should create an instance', () => {
    const directive = new MovedHouseDirective();
    expect(directive).toBeTruthy();
  });
});

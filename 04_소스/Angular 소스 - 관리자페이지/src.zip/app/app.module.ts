import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { GoogleChartsModule } from 'angular-google-charts';
import { TextareaAutosizeModule } from 'ngx-textarea-autosize';
import { SwiperModule } from 'ngx-swiper-wrapper';
import { SWIPER_CONFIG } from 'ngx-swiper-wrapper';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { NgDaumAddressModule } from 'ng2-daum-address';
import { AngularFileUploaderModule } from "angular-file-uploader";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OnSaleComponent } from './on-sale/on-sale.component';
import { DashboardChartComponent } from './dashboard-chart/dashboard-chart.component';
import { MenuComponent } from './menu/menu.component';
import { MovedHouseDirective } from './on-sale/moved-house.directive';
import { DashboardBoardComponent } from './dashboard-board/dashboard-board.component';
import { RegisterComponent } from './register/register.component';

const DEFAULT_SWIPER_CONFIG: SwiperConfigInterface = {
  direction: 'horizontal',
  slidesPerView: 1
};

@NgModule({
  declarations: [
    AppComponent,
    OnSaleComponent,
    DashboardChartComponent,
    MenuComponent,
    MovedHouseDirective,
    DashboardBoardComponent,
    RegisterComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    DragDropModule,
    GoogleChartsModule,
    BrowserAnimationsModule,
    TextareaAutosizeModule, //npm i ngx-textarea-autosize
    SwiperModule,//npm i ngx-swiper-wrapper
    NgDaumAddressModule,//npm i ng2-daum-address
    AngularFileUploaderModule,//npm i angular-file-uploader

  ],
  providers: [
    {
      provide: SWIPER_CONFIG,
      useValue: DEFAULT_SWIPER_CONFIG
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

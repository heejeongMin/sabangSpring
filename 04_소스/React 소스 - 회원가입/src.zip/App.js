import React, { Component } from 'react';
import './App.css';

// import {DelMbr} from './component/DelMbr';

import axios from 'axios';
import { SignMbr } from './component/SignMbr';


class App extends Component {

  state = {
    res : ''
  }
  
  render() {
    return (
      <div className = "wrap">
      <div className="App">
      {/* <h2>회원탈퇴</h2>
        <DelMbr onDelete = {this.delete} res = {this.state.res} /> */}
        <p className = "title"> Welcome to<br/> Sabang!</p>
        <SignMbr/>
      </div>
      </div>
    );
  }
 

 

    // delete=({userid,passwd})=>{
    //   var url = "http://localhost:8090/sabang/react/delMbrId";
    //   axios.get(url, {params : {userid: userid.value, passwd:passwd.value}} )
    //   .then( (response)=> this.setState({
    //     res : response.data
    //   }))
    // .catch((error) => {
    //   console.log(error)
    // });
    // }

    // login = (data) => {
    // //  var url = "http://localhost:8090/sabang/react/loginUI";
    // axios.get(url, {params : ) 


    // } 


  }

export default App;

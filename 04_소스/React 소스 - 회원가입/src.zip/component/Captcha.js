import React, { Component } from 'react';

export class Captcha extends Component {
    render(){
        const key = 'i1zvtpDN9QH3Jqf2';
        return(
            <>
            <div id = "capt" class = "live" data-fail ="" ></div>
	<div id = "captcha_space">
	<div id ="captcha_img_container">
	<span class="captcha_img"><img name='captchaImage' id='chptchaimg' src='https://openapi.naver.com/v1/captcha/ncaptcha.bin?key= width='30%' height='87' alt='자동입력 방지문자'/></span>
	</div>
	<br/>
    <input type="button" value="이미지 새로고침" id="captImg"/><br/>
	<input type="text" id="input" name="input"/>
	<input type = "button" id = "captSub" value = "제출"/>
	</div>
            </>
        )
    }
}

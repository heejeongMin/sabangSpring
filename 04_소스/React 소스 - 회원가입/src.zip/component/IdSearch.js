import React, { Component } from 'react';


export class IdSearch extends Component {

 
  render(){
    const {onSearch, res} = this.props;
    this.xxx = onSearch;
  
    if (this.refs.userid ==  undefined || this.refs.userid.value.length == 0 || res== 'Y'){ 
    //  document.getElementById("userid").appendChild(node)
 //   document.body.appendChild(node)
     this.isAble = '';
    }else if (res == 'N') {
        this.isAble = "이미 사용 중인 아이디입니다." 
        // var node = document.createTextNode(this.isAble); 
        // document.getElementById("place").appendChild(node)
        // console.log(node)
    }
  //  this.result(this.isAble);

  return(
    <>
      <input type = "text" ref = "userid" id = "userid" placeholder = "아이디" onChange={() => this.xxx(this.refs)}/><br/>
       {/* <div id ="place"></div>  */}
       {this.isAble}
    </>
  )
  } 

  // componentDidUpdate(){
  //  var result =document.createTextNode(this.state.node)
  //  console.log(result)
  //  console.log(result == '')
  //  console.log(result === undefined)
  //  if (result != 'undefined'){
  //   document.getElementById("place").appendChild(result)
  //  }
  // }

//   result(value){
//     if(value != ""){
//      document.getElementById("place").innerText = value
//     }
// }
}



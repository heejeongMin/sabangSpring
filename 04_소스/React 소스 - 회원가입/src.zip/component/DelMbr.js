import React, { Component } from 'react';


export class DelMbr extends Component {
  render(){

    const {onDelete, res} = this.props;
    this.xxx = onDelete;
    if (res== 'YY'){
      this.isAble = "탈되되었습니다"
    }else if (res == 'NN') {
      this.isAble = "아이디 혹은 비밀번호를 확인해주세요"
    }
  
  return(
    <>
      아이디 <input type = "text" ref = "userid"/><br/> 
      비밀번호 <input type = "password" ref = "passwd"/><br/>
      <button onClick = {() => this.xxx( this.refs ) } > 탈퇴</button>
      <br/> 
      결과 : {this.isAble}
    
    </>
  )



  } 

}




import React, { Component } from 'react';
import {DaumAddressSearch} from './DaumAddressSearch';
import {IdSearch} from './IdSearch'

import axios from 'axios';


export class SignMbr extends Component {

  state = {
   res : '',
   email: '',
   passwd : '',
   cfpswd : ''
    }

  render(){
    this.test = false
    var a = this.state.passwd
    var b = this.state.cfpswd
    if ( a == "" || a.length == 0 || b == "" || b.length == 0 || a == b){
      this.correct = ""
    }else {
      this.correct = "비밀번호가 일치하지 않습니다."
    }
    // const {onSign, res} = this.props;
    // this.xxx = onSign;
    // if (res== 'W'){
    //   this.isAble = "사방팔방 곳곳의 방에 오신 것을 환영합니다."
    // }else if (res == 'R') {
    //   this.isAble = "다시 돌아와 주었군요! 재가입을 환영합니다."
    // }else if (res == 'B') {
    //   this.isAble = "탈퇴한 회원은 24시간 이내에 재가입 할 수 없습니다. 시간 경과후 다시 시도해 주시길 바랍니다."
    // }
  
  return(
    <>
          <input type = "radio" id = "selectMbr" ref = "type" name = "agent" value = 'N'  defaultChecked = "true"   onChange = {(e)=> this.radioHandle(e.target.value)}/> <span>일반 회원</span>
        <input type = "radio" id = "selectAgnt" ref = "type" name = "agent" value = 'Y'  onChange = {(e)=> this.radioHandle(e.target.value)}/> <span>공인중개사</span>  <br/>
        <input type = "text" ref ="username" placeholder = "이름"></input>
        <IdSearch ref = "IdComp" onSearch = {this.search} res = {this.state.res} />
      <input type = "password" ref = "passwd" onKeyUp  = { (e) => { this.pswd(e.target.value)} } placeholder="비밀번호"/><br/>
      <input type = "password" ref = "cnfPasswd"  onKeyUp = { (e) => { this.cfpw(e.target.value) }} placeholder = "비밀번호 확인"/><br/> 
      {this.correct}
      <input type = "text" name = "ssn1" id = "ssn1" ref = "ssn1" placeholder = "주민등록번호 앞자리" /> - <input type = "password" ref = "ssn2" id = "ssn2" name = "ssn2" placeholder = "주민등록번호 뒷자리"></input>
      <input type = "text" ref = "email1" placeholder = "이메일"/> @ <input type = "text" ref = "email2" value = {this.state.email} onChange = {()=> this.direct(this.refs)} placeholder="직접입력"/><br/>
      <select id="email3"  ref = "email3" onChange = { () => this.emailValue(this.refs)} >
		<option value="" >이메일 선택</option>
		<option value="naver.com">naver.com</option>
		<option value="hanmail.net">hanmail.net</option>
		<option value="yahoo.co.kr">yahoo.co.kr</option>
		<option value="paran.com">paran.com</option>
		<option value="nate.com">nate.com</option>
		<option value="empal.com">empal.com</option>
		<option value="dreamwiz.com">dreamwiz.com</option>
		<option value="hanafos.com">hanafos.com</option>
		<option value="korea.com">korea.com</option>
		<option value="chol.com">chol.com</option>
		<option value="gmail.com">gmail.com</option>
		<option value="lycos.co.kr">lycos.co.kr</option>
		<option value="netian.com">netian.com</option>
		<option value="hanmir.com">hanmir.com</option>
		<option value="sayclub.com">sayclub.com</option>
	</select> <br/>
  <select ref = "phone1" name="phone1" id = "phone1">
  <option value="010">010</option>
  <option value="011">011</option>
</select>-
<input type="text" name="phone2" ref = "phone2" id = "phone2" placeholder = "핸드폰 번호 앞자리"/>-<input type="text" name="phone3" ref = "phone3" id = "phone3"  placeholder = "핸드폰 번호 뒷자리"/>
      <input type="text" name="post" ref="post" id="sample4_postcode" placeholder="우편번호" value = {this.state.res.zonecode}  />
      <input type="text" ref="addr"  placeholder="도로명주소" value = {this.state.res.roadAddress}  />
     <DaumAddressSearch onAddr = {(e) => this.addrValue(e)} /> 
        <br/>
       <div id = "submitBtn">
      <button onClick = {(e) => this.submit( this.refs ) } > 가입</button>
      </div> 
      <br/> 

    </>
  )
} //end render()

addrValue({zonecode,roadAddress}){
  this.setState({res:{zonecode,roadAddress}});
}
emailValue(e){
  this.setState({email:e.email3.value})
}

direct(e){
  this.setState({email:e.email2.value})
}


pswd(e){
  this.setState({passwd:e})
}

cfpw(e){
  this.setState({cfpswd:e})
}

// submit({IdComp, type, passwd,email1}){
//   console.log(IdComp.refs.userid.value, type.value, passwd.value,email1.value)
// }


radioHandle(e){
  this.test = true
}

// submit=({type, IdComp, passwd,email1 , email2, phone1, phone2, phone3, ssn1, ssn2}) =>{
//   var url = "http://localhost:8090/sabang/react/signMbr";
//        axios.get(url, {headers : {"Access-Control-Allow-Origin":"*", 'Content-Type': 'application/json; charset=UTF-8'} },
//       {params : {agent : type.vlaue, email1: email1.value, email2:email2.value,
//        userid: IdComp.refs.userid.value, passwd : passwd.value, phone1:phone1.value,
//        phone2:phone2.value, phone3:phone3.value,  ssn1:ssn1.value,  ssn2:ssn2.value
//       } })
//       .then((response) => 
//       {console.log(response)})
//       .catch((error) => {console.log(error.response)})
// }

//,email1 , email2, phone1, phone2, phone3, ssn1, ssn2
//   email1: email1.value,
// email2:email2.value,
// type, IdComp, passwd,email1, email2,phone1,phone2,phone3,addr,post, ssn1, ssn2
submit=({type, IdComp, passwd,email1, email2,phone1,phone2,phone3,addr,post, ssn1, ssn2,username}) =>{
console.log(username.value, type.value,IdComp.refs.userid.value, passwd.value,email1.value, email2.value,phone1.value,phone2.value,phone3.value,addr.value,post.value, ssn1.value, ssn2.value)
  var url = "http://localhost:8090/sabang/react/signMbr";
       axios.post(url,
        {
                 agent : type.value,
                  userid: IdComp.refs.userid.value,
                  passwd : passwd.value,
                   email1 : email1.value,
                   email2 : email2.value,
                   phone1:phone1.value,
                   phone2:phone2.value, 
                   phone3:phone3.value,
                   ssn1:ssn1.value,  
                   ssn2:ssn2.value,
                   addr : addr.value,
                   post : post.value,
                   username : username.value
          
        } ,{headers : { 'Content-Type': 'application/json'}})
          .then((response) => 
          {if(response.data == 'W'){
            alert("사방팔방 곳곳의 방에 오신 것을 환영합니다")}else if(response.data == 'C'){
              alert("다시 돌아와 주었군요! 재가입을 환영합니다.")
            }else if (response.data == 'O'){
              alert("탈퇴한 회원은 24시간 이내에 재가입 할 수 없습니다. 시간 경과후 다시 시도해 주시길 바랍니다.")
            }
          })
          .catch((error) => {console.log(error.response)})
}



// submit=({type, IdComp, passwd,email1 , email2, phone1, phone2, phone3}) =>{
//   console.log (  type.value, IdComp.refs.userid.value, 
//              passwd.value, email1.value,email2.value,
//              phone1.value, phone2.value, phone3.value)
//   axios({
//     method: 'post',
//     url: "http://localhost:8090/sabang/react/signMbr",
//     data: {
//       agent: type.value, 
//       userid: IdComp.refs.userid.value, 
//       passwd:  passwd.value,
//       email1 : email1.value,
//       email2 : email2.value,
//       phone1:phone1.value,
//       phone2 :  phone2.value,
//       phone3 :  phone3.value
//     },
//     headers: {
//             'Content-Type': 'application/json; charset=UTF-8',
//             "Access-Control-Allow-Origin":"*"
//     }
//   }).then((response) => {
//     console.log('token', response);
// })
// .catch((error) => console.log('error' , error.response));
// }


search=(data)=>{
  var url = "http://localhost:8090/sabang/react/idCheck";
  axios.get(url, {params : {id: data.userid.value}} )
      .then( (response)=> this.setState({
        res : response.data
      }))
    .catch((error) => {
      console.log(error)
    });
  } 


}


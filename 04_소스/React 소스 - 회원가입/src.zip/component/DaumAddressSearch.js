import React, { Component } from 'react';
import PropTypes from 'prop-types';

export class DaumAddressSearch extends Component {
  state = {
    zonecode : '',
    roadAddress : ''
  }

  search = () =>{
    const script = document.createElement('script');
    script.src = this.props.scriptUrl;
    script.onload = () => {
      this.initiate(this);
    };
    document.body.appendChild(script);
  }
  componentWillReceiveProps(nextProps){
    if(nextProps.visible){
      this.initiate(this);
    }
  }
  initiate = (comp) => {
    window.daum.postcode.load(() => {
      const Postcode = new window.daum.Postcode({
        oncomplete: function oncomplete(data) {
          comp.setState({zonecode: data.zonecode, roadAddress: data.roadAddress});
          comp.props.onAddr(comp.state)
        },
        onresize: function onresize(size) {
          if (comp.props.autoResize) comp.setState({ height: size.height });
       },
        animation: comp.props.animation,
        autoMapping: comp.props.autoMapping,
        shorthand: comp.props.shorthand,
        pleaseReadGuide: comp.props.pleaseReadGuide,
        pleaseReadGuideTimer: comp.props.pleaseReadGuideTimer,
        maxSuggestItems: comp.props.maxSuggestItems,
        showMoreHName: comp.props.showMoreHName,
        hideMapBtn: comp.props.hideMapBtn,
        hideEngBtn: comp.props.hideEngBtn,
        width: comp.props.width,
        height: comp.props.height,
      }).open({
        autoClose : true
      });
      // if(this.daumSearch){
      //   Postcode.embed(this.daumSearch);
      // }
    });
  }
  
  open(e){
    console.log(e)
  }

  render() {
    this.script = this.props.xxx
    
    return (
      <>
      <div ref={ref => this.daumSearch = ref}>
      </div>
     <button onClick = {() => this.search(this.refs)}>주소찾기</button>  
      </>
    );
  }
  
}
DaumAddressSearch.propTypes = {
  visible: PropTypes.bool.isRequired,
  scriptUrl: PropTypes.string.isRequired,
};
DaumAddressSearch.defaultProps = {
  width: 400,
  height: 500,
  autoClose: true,
  autoResize: false,
  animation: false,
  autoMapping: true,
  shorthand: true,
  pleaseReadGuide: 0,
  pleaseReadGuideTimer: 1.5,
  maxSuggestItems: 10,
  showMoreHName: false,
  hideMapBtn: false,
  hideEngBtn: false,
  style: null,
  defaultQuery: null,
  theme: null,
 scriptUrl: 'http://dmaps.daum.net/map_js_init/postcode.v2.js?autoload=false', 
  visible: false
};
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(<App />, document.getElementById('root')); // 사용자 정의 컴포넌트를 렌더하는 태그
// id가 root인 엘리먼트를 찾아 <app />를 적용하라,
//  <app />는 app.js의 컴포넌트 명



// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();

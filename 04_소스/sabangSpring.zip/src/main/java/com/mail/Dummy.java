package com.mail;

public class Dummy {

}

$(document).ready(function(){
		
});//end ready